"""
EduGlobal AI Learning Hub - Database Engine
Offline-first SQLite schema initialization and robust CRUD operations.
Database file: eduglobal_offline.db
"""

import os
import re
import uuid
import sqlite3
import hashlib
import json
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple

# Dynamic base directory resolution across parent and root directories
BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "eduglobal_offline.db"

# Core Standard Subjects List
CORE_SUBJECTS = [
    "Computer Science",
    "Physics",
    "Mathematics",
    "Chemistry",
    "English",
    "Urdu",
    "Islamiat",
    "General Science"
]

# Standard Academic Levels
ACADEMIC_LEVELS = [
    "Metric / O-Level",
    "HSSC-I (FSc / ICS / FA Part 1)",
    "HSSC-II (FSc / ICS / FA Part 2)",
    "A-Level",
    "Undergraduate"
]

# Standard Supported Languages
SUPPORTED_LANGUAGES = [
    "English",
    "Urdu",
    "Urdu/English",
    "Roman Urdu"
]


def get_db_connection() -> sqlite3.Connection:
    """Creates a thread-safe connection to the SQLite database with WAL mode."""
    conn = sqlite3.connect(str(DB_PATH), check_same_thread=False)
    conn.row_factory = sqlite3.Row
    # Enable WAL mode for high concurrency and performance
    conn.execute("PRAGMA journal_mode=WAL;")
    conn.execute("PRAGMA foreign_keys=ON;")
    return conn


def hash_password(password: str, salt: str = "eduglobal_salt_2026") -> str:
    """Hashes a plain text password using SHA-256 with a secure salt."""
    salted = f"{salt}:{password}:{salt}"
    return hashlib.sha256(salted.encode("utf-8")).hexdigest()


def verify_password(plain_password: str, hashed_password: str, salt: str = "eduglobal_salt_2026") -> bool:
    """Verifies a plain text password against the stored SHA-256 hash."""
    return hash_password(plain_password, salt) == hashed_password


def init_db():
    """Initializes all database tables and applies safe automatic column migrations."""
    conn = get_db_connection()
    cursor = conn.cursor()

    # 1. Users table with enhanced profile fields
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        full_name TEXT NOT NULL,
        college_name TEXT DEFAULT '',
        academic_level TEXT DEFAULT 'Metric / O-Level',
        target_exams TEXT DEFAULT 'Computer Science, Physics, Mathematics',
        default_language TEXT DEFAULT 'English',
        education_level TEXT DEFAULT 'Metric / O-Level',
        preferred_language TEXT DEFAULT 'English',
        target_exam TEXT DEFAULT '',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    """)

    # Check and migrate columns in users table if needed
    cursor.execute("PRAGMA table_info(users);")
    existing_cols = {row["name"] for row in cursor.fetchall()}

    if "college_name" not in existing_cols:
        cursor.execute("ALTER TABLE users ADD COLUMN college_name TEXT DEFAULT '';")
    if "academic_level" not in existing_cols:
        cursor.execute("ALTER TABLE users ADD COLUMN academic_level TEXT DEFAULT 'Metric / O-Level';")
    if "target_exams" not in existing_cols:
        cursor.execute("ALTER TABLE users ADD COLUMN target_exams TEXT DEFAULT 'Computer Science, Physics, Mathematics';")
    if "default_language" not in existing_cols:
        cursor.execute("ALTER TABLE users ADD COLUMN default_language TEXT DEFAULT 'English';")
    if "education_level" not in existing_cols:
        cursor.execute("ALTER TABLE users ADD COLUMN education_level TEXT DEFAULT 'Metric / O-Level';")
    if "preferred_language" not in existing_cols:
        cursor.execute("ALTER TABLE users ADD COLUMN preferred_language TEXT DEFAULT 'English';")
    if "target_exam" not in existing_cols:
        cursor.execute("ALTER TABLE users ADD COLUMN target_exam TEXT DEFAULT '';")
    if "gemini_api_key" not in existing_cols:
        cursor.execute("ALTER TABLE users ADD COLUMN gemini_api_key TEXT DEFAULT '';")
    if "auth_provider" not in existing_cols:
        cursor.execute("ALTER TABLE users ADD COLUMN auth_provider TEXT DEFAULT 'local';")
    if "google_id" not in existing_cols:
        cursor.execute("ALTER TABLE users ADD COLUMN google_id TEXT DEFAULT '';")
    if "avatar_url" not in existing_cols:
        cursor.execute("ALTER TABLE users ADD COLUMN avatar_url TEXT DEFAULT '';")

    # 2. Chat Sessions table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS chat_sessions (
        id TEXT PRIMARY KEY,
        user_id INTEGER NOT NULL,
        title TEXT NOT NULL,
        language TEXT DEFAULT 'English',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
    );
    """)

    # 3. Chat Messages table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS chat_messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        session_id TEXT NOT NULL,
        role TEXT NOT NULL,
        content TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (session_id) REFERENCES chat_sessions (id) ON DELETE CASCADE
    );
    """)

    # 4. PDF Documents table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS pdf_documents (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        filename TEXT NOT NULL,
        file_hash TEXT NOT NULL,
        total_pages INTEGER DEFAULT 1,
        total_chunks INTEGER DEFAULT 0,
        summary TEXT DEFAULT '',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
    );
    """)

    # 5. PDF Chunks table for RAG retrieval
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS pdf_chunks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        doc_id INTEGER NOT NULL,
        chunk_index INTEGER NOT NULL,
        content TEXT NOT NULL,
        page_number INTEGER DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (doc_id) REFERENCES pdf_documents (id) ON DELETE CASCADE
    );
    """)

    # 6. Quiz Results table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS quiz_results (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        topic TEXT NOT NULL,
        subject TEXT DEFAULT 'General Science',
        difficulty TEXT DEFAULT 'Medium',
        score INTEGER NOT NULL,
        total_questions INTEGER NOT NULL,
        percentage REAL NOT NULL,
        time_taken_seconds INTEGER DEFAULT 0,
        details_json TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
    );
    """)

    # 7. Offline Lessons table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS offline_lessons (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        subject TEXT NOT NULL,
        topic TEXT NOT NULL,
        language TEXT DEFAULT 'English',
        summary TEXT NOT NULL,
        full_content_markdown TEXT NOT NULL,
        key_takeaways TEXT DEFAULT '',
        is_cached INTEGER DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
    );
    """)

    # 8. Study Groups table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS study_groups (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        description TEXT DEFAULT '',
        subject TEXT DEFAULT 'General Science',
        join_code TEXT UNIQUE NOT NULL,
        creator_id INTEGER NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (creator_id) REFERENCES users (id) ON DELETE CASCADE
    );
    """)

    # 9. Group Memberships table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS group_members (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        group_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        role TEXT DEFAULT 'member',
        joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE (group_id, user_id),
        FOREIGN KEY (group_id) REFERENCES study_groups (id) ON DELETE CASCADE,
        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
    );
    """)

    # 10. Group In-App Chat Messages
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS group_messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        group_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        message TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (group_id) REFERENCES study_groups (id) ON DELETE CASCADE,
        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
    );
    """)

    # 11. Group Shared Documents (PDF Notes)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS group_shared_documents (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        group_id INTEGER NOT NULL,
        doc_id INTEGER NOT NULL,
        shared_by INTEGER NOT NULL,
        notes TEXT DEFAULT '',
        shared_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (group_id) REFERENCES study_groups (id) ON DELETE CASCADE,
        FOREIGN KEY (doc_id) REFERENCES pdf_documents (id) ON DELETE CASCADE,
        FOREIGN KEY (shared_by) REFERENCES users (id) ON DELETE CASCADE
    );
    """)

    # 12. Group Shared Quizzes & Peer Challenges
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS group_shared_quizzes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        group_id INTEGER NOT NULL,
        quiz_result_id INTEGER NOT NULL,
        shared_by INTEGER NOT NULL,
        topic TEXT NOT NULL,
        score_summary TEXT NOT NULL,
        quiz_json TEXT NOT NULL,
        shared_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (group_id) REFERENCES study_groups (id) ON DELETE CASCADE,
        FOREIGN KEY (quiz_result_id) REFERENCES quiz_results (id) ON DELETE CASCADE,
        FOREIGN KEY (shared_by) REFERENCES users (id) ON DELETE CASCADE
    );
    """)

    # 13. Persistent Active User Sessions for Instant Auto-Connect / Auto-Sign-In
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS active_sessions (
        id INTEGER PRIMARY KEY CHECK (id = 1),
        user_id INTEGER NOT NULL,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
    );
    """)

    # 14. Exam Subjects & Readiness Tracker
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS exam_subjects (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        subject_name TEXT NOT NULL,
        target_date TEXT DEFAULT '',
        readiness_percentage INTEGER DEFAULT 50,
        target_score TEXT DEFAULT 'A* (90%+)',
        notes TEXT DEFAULT '',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
    );
    """)

    # 15. Exam Flashcards Deck
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS exam_flashcards (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        subject TEXT NOT NULL,
        topic TEXT NOT NULL,
        front_text TEXT NOT NULL,
        back_text TEXT NOT NULL,
        category TEXT DEFAULT 'Concept',
        status TEXT DEFAULT 'new', -- 'new', 'review', 'mastered'
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
    );
    """)

    # 16. Exam Mind Maps
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS exam_mindmaps (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        subject TEXT NOT NULL,
        topic TEXT NOT NULL,
        mermaid_code TEXT NOT NULL,
        summary TEXT DEFAULT '',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
    );
    """)

    # 17. Exam Model Paper Analysis & Guess Papers (Paper Crack)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS exam_guess_papers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        subject TEXT NOT NULL,
        exam_board TEXT NOT NULL,
        academic_level TEXT NOT NULL,
        model_paper_input TEXT DEFAULT '',
        analysis_json TEXT DEFAULT '{}',
        guess_paper_markdown TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
    );
    """)

    # 18. Exam Revision Cheat Sheets & Smart Notes
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS exam_revision_notes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        subject TEXT NOT NULL,
        topic TEXT NOT NULL,
        notes_markdown TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
    );
    """)

    conn.commit()
    conn.close()


def _format_user_row(row: sqlite3.Row) -> Dict[str, Any]:
    """Helper to convert sqlite3.Row to user dictionary with normalized profile fields."""
    d = dict(row)
    academic_level = d.get("academic_level") or d.get("education_level") or "Metric / O-Level"
    default_language = d.get("default_language") or d.get("preferred_language") or "English"
    target_exams = d.get("target_exams") or d.get("target_exam") or "Computer Science, Physics, Mathematics"
    college_name = d.get("college_name") or ""
    gemini_api_key = d.get("gemini_api_key") or ""
    auth_provider = d.get("auth_provider") or "local"
    google_id = d.get("google_id") or ""
    avatar_url = d.get("avatar_url") or ""

    return {
        "id": d["id"],
        "username": d["username"],
        "email": d["email"],
        "full_name": d["full_name"],
        "college_name": college_name,
        "academic_level": academic_level,
        "target_exams": target_exams,
        "default_language": default_language,
        "gemini_api_key": gemini_api_key,
        "auth_provider": auth_provider,
        "google_id": google_id,
        "avatar_url": avatar_url,
        # Backward compatibility aliases
        "education_level": academic_level,
        "preferred_language": default_language,
        "target_exam": target_exams,
        "created_at": str(d.get("created_at", ""))
    }


def clean_gemini_api_key_input(raw_key: Optional[str]) -> str:
    """
    Cleans and normalizes user input for Gemini API key.
    Handles 'GEMINI_API_KEY=AIzaSy...', quotes, and whitespaces.
    """
    if not raw_key:
        return ""
    cleaned = raw_key.strip()
    # Strip prefixes like 'GEMINI_API_KEY=' or 'gemini_api_key='
    if "=" in cleaned:
        cleaned = cleaned.split("=", 1)[1].strip()
    # Strip quotes
    cleaned = cleaned.strip('"\'`')
    return cleaned


def save_gemini_key_to_env(api_key: str):
    """
    Persists the Gemini API key directly to .env file and environment variables
    so it auto-connects and survives restarts.
    """
    cleaned = clean_gemini_api_key_input(api_key)
    if not cleaned or cleaned in ("MY_GEMINI_API_KEY", "your_gemini_api_key_here", "None"):
        return

    os.environ["GEMINI_API_KEY"] = cleaned

    env_paths = [BASE_DIR / ".env", Path(".env")]
    for env_path in env_paths:
        try:
            lines = []
            replaced = False
            if env_path.exists():
                lines = env_path.read_text(encoding="utf-8").splitlines()
                for i, line in enumerate(lines):
                    if line.strip().startswith("GEMINI_API_KEY="):
                        lines[i] = f"GEMINI_API_KEY={cleaned}"
                        replaced = True
                        break
            if not replaced:
                lines.append(f"GEMINI_API_KEY={cleaned}")
            env_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
        except Exception:
            pass


# ----------------------------------------------------------------------
# USER AUTHENTICATION & PROFILE CRUD WITH PERSISTENT AUTO-LOGIN
# ----------------------------------------------------------------------

SESSION_CACHE_FILE = BASE_DIR / ".active_session.json"


def set_persistent_session(user_id: int):
    """Persists the active logged-in user so they stay auto-logged in across reloads/reconnects."""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("INSERT OR REPLACE INTO active_sessions (id, user_id, updated_at) VALUES (1, ?, CURRENT_TIMESTAMP)", (user_id,))
        conn.commit()
        conn.close()
    except Exception:
        pass

    try:
        data = {"user_id": user_id, "timestamp": time.time()}
        SESSION_CACHE_FILE.write_text(json.dumps(data), encoding="utf-8")
    except Exception:
        pass


def get_persistent_session() -> Optional[Dict[str, Any]]:
    """Retrieves the currently persisted user session for instant direct login."""
    # 1. Check database active_sessions table
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT user_id FROM active_sessions WHERE id = 1")
        row = cursor.fetchone()
        conn.close()
        if row and row["user_id"]:
            u = get_user_by_id(row["user_id"])
            if u:
                return u
    except Exception:
        pass

    # 2. Check JSON file fallback
    try:
        if SESSION_CACHE_FILE.exists():
            data = json.loads(SESSION_CACHE_FILE.read_text(encoding="utf-8"))
            uid = data.get("user_id")
            if uid:
                u = get_user_by_id(uid)
                if u:
                    return u
    except Exception:
        pass

    return None


def clear_persistent_session():
    """Clears the persisted session on explicit logout."""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("DELETE FROM active_sessions WHERE id = 1")
        conn.commit()
        conn.close()
    except Exception:
        pass

    try:
        if SESSION_CACHE_FILE.exists():
            SESSION_CACHE_FILE.unlink()
    except Exception:
        pass


def get_all_users_summary() -> List[Dict[str, Any]]:
    """Returns all registered student profiles for quick 1-click direct sign in."""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT id, username, email, full_name, academic_level, college_name FROM users ORDER BY id DESC")
        rows = cursor.fetchall()
        conn.close()
        return [dict(r) for r in rows]
    except Exception:
        return []


def update_user_gemini_api_key(user_id: int, api_key: str) -> bool:
    """Updates the Gemini API key for a specific user and syncs to environment and .env."""
    cleaned = clean_gemini_api_key_input(api_key)
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("UPDATE users SET gemini_api_key = ? WHERE id = ?", (cleaned, user_id))
        conn.commit()
        if cleaned:
            save_gemini_key_to_env(cleaned)
        return cursor.rowcount > 0
    finally:
        conn.close()


def get_or_create_google_user(email: str, full_name: Optional[str] = None,
                              google_id: Optional[str] = None,
                              avatar_url: Optional[str] = None,
                              gemini_api_key: Optional[str] = None) -> Optional[Dict[str, Any]]:
    """
    Finds existing user by Google email or registers them automatically.
    Attaches their Gemini API key, persists the session, and saves to .env.
    """
    clean_email = (email or "").strip().lower()
    if not clean_email or "@" not in clean_email:
        return None

    cleaned_key = clean_gemini_api_key_input(gemini_api_key)

    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users WHERE LOWER(email) = ?", (clean_email,))
    row = cursor.fetchone()

    if row:
        user_id = row["id"]
        # Update google_id and gemini_api_key if provided
        updates = []
        params = []
        if google_id:
            updates.append("google_id = ?")
            params.append(google_id)
        if avatar_url:
            updates.append("avatar_url = ?")
            params.append(avatar_url)
        if cleaned_key:
            updates.append("gemini_api_key = ?")
            params.append(cleaned_key)
        if updates:
            params.append(user_id)
            cursor.execute(f"UPDATE users SET {', '.join(updates)} WHERE id = ?", tuple(params))
            conn.commit()
        conn.close()

        if cleaned_key:
            save_gemini_key_to_env(cleaned_key)
        elif row["gemini_api_key"]:
            save_gemini_key_to_env(row["gemini_api_key"])

        user = get_user_by_id(user_id)
        if user:
            set_persistent_session(user["id"])
        return user

    # Derive name if not provided
    name = (full_name or "").strip()
    if not name:
        prefix = clean_email.split("@")[0].replace(".", " ").replace("_", " ").title()
        name = prefix or "Google Scholar"

    # Derive unique username
    base_username = re.sub(r'[^a-zA-Z0-9_]', '', clean_email.split("@")[0].lower())[:20]
    if len(base_username) < 3:
        base_username = f"google_{base_username}"
    username = base_username
    counter = 1
    while True:
        cursor.execute("SELECT id FROM users WHERE LOWER(username) = ?", (username.lower(),))
        if not cursor.fetchone():
            break
        username = f"{base_username}_{counter}"
        counter += 1

    import secrets
    random_pwd = secrets.token_urlsafe(16)
    pwd_hash = hash_password(random_pwd)

    cursor.execute("""
        INSERT INTO users (
            username, email, password_hash, full_name, college_name,
            academic_level, target_exams, default_language,
            education_level, preferred_language, target_exam,
            gemini_api_key, auth_provider, google_id, avatar_url
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'google', ?, ?)
    """, (
        username, clean_email, pwd_hash, name,
        "", "Metric / O-Level", "Computer Science, Physics, Mathematics", "Urdu/English",
        "Metric / O-Level", "Urdu/English", "Computer Science, Physics, Mathematics",
        cleaned_key, google_id or "", avatar_url or ""
    ))
    conn.commit()
    new_id = cursor.lastrowid
    conn.close()

    if cleaned_key:
        save_gemini_key_to_env(cleaned_key)

    created = get_user_by_id(new_id)
    if created:
        set_persistent_session(created["id"])
    return created


def create_user(username: str, email: str, password_raw: str, full_name: str,
                academic_level: str = "Metric / O-Level",
                default_language: str = "English",
                target_exams: str = "Computer Science, Physics, Mathematics",
                college_name: str = "",
                education_level: Optional[str] = None,
                preferred_language: Optional[str] = None,
                target_exam: Optional[str] = None,
                gemini_api_key: Optional[str] = None) -> Optional[Dict[str, Any]]:
    """Registers a new user with hashed password and comprehensive academic profile, auto-persisting session."""
    conn = get_db_connection()
    cursor = conn.cursor()
    pwd_hash = hash_password(password_raw)

    level = academic_level or education_level or "Metric / O-Level"
    lang = default_language or preferred_language or "English"
    exams = target_exams or target_exam or "Computer Science, Physics, Mathematics"
    college = college_name or ""
    cleaned_key = clean_gemini_api_key_input(gemini_api_key)

    try:
        cursor.execute("""
            INSERT INTO users (
                username, email, password_hash, full_name, college_name,
                academic_level, target_exams, default_language,
                education_level, preferred_language, target_exam,
                gemini_api_key
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            username.strip().lower(), email.strip().lower(), pwd_hash, full_name.strip(),
            college.strip(), level.strip(), exams.strip(), lang.strip(),
            level.strip(), lang.strip(), exams.strip(),
            cleaned_key
        ))
        conn.commit()
        user_id = cursor.lastrowid
        created = get_user_by_id(user_id)
        if created:
            set_persistent_session(created["id"])
            if cleaned_key:
                save_gemini_key_to_env(cleaned_key)
        return created
    except sqlite3.IntegrityError:
        return None
    finally:
        conn.close()


def authenticate_user(username_or_email: str, password_raw: str,
                      gemini_api_key: Optional[str] = None) -> Optional[Dict[str, Any]]:
    """
    Authenticates user with resilient matching (username, email, or full name).
    Supports whitespace tolerance, optional Gemini API key sync, and automatic session persistence.
    """
    if not username_or_email or not password_raw:
        return None

    conn = get_db_connection()
    cursor = conn.cursor()
    clean_identifier = username_or_email.strip().lower()
    clean_pwd = password_raw.strip()

    # Search flexibly by username, email, or full_name
    cursor.execute("""
        SELECT * FROM users 
        WHERE LOWER(username) = ? OR LOWER(email) = ? OR LOWER(full_name) = ?
    """, (clean_identifier, clean_identifier, clean_identifier))
    rows = cursor.fetchall()
    conn.close()

    if not rows:
        return None

    cleaned_key = clean_gemini_api_key_input(gemini_api_key)

    for row in rows:
        stored_hash = row["password_hash"]
        if (verify_password(password_raw, stored_hash) or 
            verify_password(clean_pwd, stored_hash) or
            verify_password(password_raw.rstrip("\r\n"), stored_hash)):
            user_data = _format_user_row(row)
            
            # If user provided a new key on login, save it
            if cleaned_key:
                update_user_gemini_api_key(user_data["id"], cleaned_key)
                user_data["gemini_api_key"] = cleaned_key
                save_gemini_key_to_env(cleaned_key)
            elif user_data.get("gemini_api_key"):
                save_gemini_key_to_env(user_data["gemini_api_key"])

            set_persistent_session(user_data["id"])
            return user_data

    return None


def get_user_by_id(user_id: int) -> Optional[Dict[str, Any]]:
    """Fetches user details by user ID."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users WHERE id = ?", (user_id,))
    row = cursor.fetchone()
    conn.close()
    if row:
        return _format_user_row(row)
    return None


def get_user_by_username(username: str) -> Optional[Dict[str, Any]]:
    """Fetches user details by username."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users WHERE username = ?", (username.strip().lower(),))
    row = cursor.fetchone()
    conn.close()
    if row:
        return _format_user_row(row)
    return None


def update_user_profile(user_id: int, full_name: str,
                        academic_level: str = "Metric / O-Level",
                        default_language: str = "English",
                        target_exams: str = "Computer Science, Physics, Mathematics",
                        college_name: str = "",
                        education_level: Optional[str] = None,
                        preferred_language: Optional[str] = None,
                        target_exam: Optional[str] = None) -> bool:
    """Updates profile attributes for a given user with backward compatibility."""
    conn = get_db_connection()
    cursor = conn.cursor()

    level = academic_level or education_level or "Metric / O-Level"
    lang = default_language or preferred_language or "English"
    exams = target_exams or target_exam or "Computer Science, Physics, Mathematics"
    college = college_name or ""

    try:
        cursor.execute("""
            UPDATE users
            SET full_name = ?, college_name = ?, academic_level = ?,
                target_exams = ?, default_language = ?,
                education_level = ?, preferred_language = ?, target_exam = ?
            WHERE id = ?
        """, (
            full_name.strip(), college.strip(), level.strip(),
            exams.strip(), lang.strip(),
            level.strip(), lang.strip(), exams.strip(),
            user_id
        ))
        conn.commit()
        return cursor.rowcount > 0
    finally:
        conn.close()


# ----------------------------------------------------------------------
# CHAT SESSIONS & MESSAGES CRUD
# ----------------------------------------------------------------------

def create_chat_session(session_id: str, user_id: int, title: str, language: str = "English") -> Dict[str, Any]:
    """Creates a new chat session."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO chat_sessions (id, user_id, title, language)
        VALUES (?, ?, ?, ?)
    """, (session_id, user_id, title, language))
    conn.commit()
    conn.close()
    return {"id": session_id, "user_id": user_id, "title": title, "language": language}


def get_user_chat_sessions(user_id: int) -> List[Dict[str, Any]]:
    """Retrieves all chat sessions for a specific user ordered by latest."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT * FROM chat_sessions WHERE user_id = ? ORDER BY updated_at DESC
    """, (user_id,))
    rows = cursor.fetchall()
    conn.close()
    return [dict(row) for row in rows]


def get_chat_session(session_id: str) -> Optional[Dict[str, Any]]:
    """Retrieves single chat session by session ID."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM chat_sessions WHERE id = ?", (session_id,))
    row = cursor.fetchone()
    conn.close()
    return dict(row) if row else None


def delete_chat_session(session_id: str) -> bool:
    """Deletes a chat session and associated messages."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM chat_sessions WHERE id = ?", (session_id,))
    conn.commit()
    deleted = cursor.rowcount > 0
    conn.close()
    return deleted


def add_chat_message(session_id: str, role: str, content: str) -> int:
    """Appends a chat message to a session and updates the session timestamp."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO chat_messages (session_id, role, content)
        VALUES (?, ?, ?)
    """, (session_id, role, content))
    cursor.execute("""
        UPDATE chat_sessions
        SET updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
    """, (session_id,))
    conn.commit()
    msg_id = cursor.lastrowid
    conn.close()
    return msg_id


def get_chat_history(session_id: str) -> List[Dict[str, Any]]:
    """Retrieves all messages for a given chat session in chronological order."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT role, content, created_at FROM chat_messages
        WHERE session_id = ? ORDER BY id ASC
    """, (session_id,))
    rows = cursor.fetchall()
    conn.close()
    return [dict(row) for row in rows]


def clear_chat_history(session_id: str) -> bool:
    """Clears all messages inside a specific session."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM chat_messages WHERE session_id = ?", (session_id,))
    conn.commit()
    conn.close()
    return True


# ----------------------------------------------------------------------
# PDF & RAG DOCUMENTS CRUD
# ----------------------------------------------------------------------

def save_pdf_document(user_id: int, filename: str, file_hash: str,
                      total_pages: int, total_chunks: int, summary: str = "") -> int:
    """Saves metadata for an uploaded PDF."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO pdf_documents (user_id, filename, file_hash, total_pages, total_chunks, summary)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (user_id, filename, file_hash, total_pages, total_chunks, summary))
    conn.commit()
    doc_id = cursor.lastrowid
    conn.close()
    return doc_id


def save_pdf_chunks(doc_id: int, chunks: List[Tuple[int, str, int]]) -> bool:
    """
    Bulk saves extracted chunks for a PDF.
    chunks parameter is a list of tuples: (chunk_index, content, page_number)
    """
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.executemany("""
        INSERT INTO pdf_chunks (doc_id, chunk_index, content, page_number)
        VALUES (?, ?, ?, ?)
    """, [(doc_id, idx, content, page) for (idx, content, page) in chunks])
    conn.commit()
    conn.close()
    return True


def get_user_pdf_documents(user_id: int) -> List[Dict[str, Any]]:
    """Retrieves all uploaded PDF documents for a user."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT * FROM pdf_documents WHERE user_id = ? ORDER BY created_at DESC
    """, (user_id,))
    rows = cursor.fetchall()
    conn.close()
    return [dict(row) for row in rows]


def search_pdf_chunks(user_id: int, query: str, limit: int = 4) -> List[Dict[str, Any]]:
    """
    Searches relevant PDF chunks using SQLite LIKE keyword matching.
    Returns matched chunks along with document name and page number.
    """
    conn = get_db_connection()
    cursor = conn.cursor()
    terms = [t.strip() for t in query.split() if len(t.strip()) > 2]
    if not terms:
        terms = [query.strip()]

    # Construct search predicate
    like_clauses = " OR ".join(["c.content LIKE ?"] * len(terms))
    sql = f"""
        SELECT c.id, c.doc_id, c.page_number, c.content, d.filename
        FROM pdf_chunks c
        JOIN pdf_documents d ON c.doc_id = d.id
        WHERE d.user_id = ? AND ({like_clauses})
        ORDER BY c.id DESC
        LIMIT ?
    """
    params = [user_id] + [f"%{term}%" for term in terms] + [limit]
    cursor.execute(sql, params)
    rows = cursor.fetchall()

    # If no strict keyword matches, fallback to latest chunks from user's documents
    if not rows:
        cursor.execute("""
            SELECT c.id, c.doc_id, c.page_number, c.content, d.filename
            FROM pdf_chunks c
            JOIN pdf_documents d ON c.doc_id = d.id
            WHERE d.user_id = ?
            ORDER BY c.id DESC
            LIMIT ?
        """, (user_id, limit))
        rows = cursor.fetchall()

    conn.close()
    return [dict(row) for row in rows]


# ----------------------------------------------------------------------
# QUIZ RESULTS & ASSESSMENTS CRUD
# ----------------------------------------------------------------------

def save_quiz_result(user_id: int, topic: str, subject: str, difficulty: str,
                     score: int, total_questions: int, percentage: float,
                     time_taken_seconds: int, details_json: str) -> int:
    """Stores a student's quiz attempt and answers."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO quiz_results (user_id, topic, subject, difficulty, score, total_questions, percentage, time_taken_seconds, details_json)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (user_id, topic, subject, difficulty, score, total_questions, percentage, time_taken_seconds, details_json))
    conn.commit()
    result_id = cursor.lastrowid
    conn.close()
    return result_id


def get_user_quiz_results(user_id: int, limit: int = 30) -> List[Dict[str, Any]]:
    """Retrieves previous quiz results for a user."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT * FROM quiz_results WHERE user_id = ? ORDER BY created_at DESC LIMIT ?
    """, (user_id, limit))
    rows = cursor.fetchall()
    conn.close()
    results = []
    for row in rows:
        item = dict(row)
        try:
            item["details"] = json.loads(item["details_json"])
        except Exception:
            item["details"] = []
        results.append(item)
    return results


def get_user_analytics_summary(user_id: int) -> Dict[str, Any]:
    """Generates an analytics report for student performance."""
    conn = get_db_connection()
    cursor = conn.cursor()

    # Total quizzes taken & average percentage
    cursor.execute("""
        SELECT COUNT(*) as total_quizzes, AVG(percentage) as avg_score, MAX(percentage) as best_score
        FROM quiz_results WHERE user_id = ?
    """, (user_id,))
    quiz_stats = cursor.fetchone()

    # Total lessons cached
    cursor.execute("""
        SELECT COUNT(*) as total_lessons FROM offline_lessons WHERE user_id = ?
    """, (user_id,))
    lesson_stats = cursor.fetchone()

    # Total chat sessions
    cursor.execute("""
        SELECT COUNT(*) as total_sessions FROM chat_sessions WHERE user_id = ?
    """, (user_id,))
    chat_stats = cursor.fetchone()

    # Subject performance breakdown
    cursor.execute("""
        SELECT subject, COUNT(*) as attempts, AVG(percentage) as avg_score
        FROM quiz_results WHERE user_id = ?
        GROUP BY subject
    """, (user_id,))
    subject_rows = cursor.fetchall()

    conn.close()

    return {
        "total_quizzes": quiz_stats["total_quizzes"] if quiz_stats else 0,
        "avg_score": round(quiz_stats["avg_score"], 1) if quiz_stats and quiz_stats["avg_score"] is not None else 0.0,
        "best_score": round(quiz_stats["best_score"], 1) if quiz_stats and quiz_stats["best_score"] is not None else 0.0,
        "total_lessons_cached": lesson_stats["total_lessons"] if lesson_stats else 0,
        "total_chat_sessions": chat_stats["total_sessions"] if chat_stats else 0,
        "subjects": [dict(r) for r in subject_rows]
    }


def get_user_learning_progress(user_id: int) -> Dict[str, Any]:
    """Calculates comprehensive student progress, XP, streak, and subject mastery across core subjects."""
    conn = get_db_connection()
    cursor = conn.cursor()

    # Quizzes count and avg
    cursor.execute("SELECT COUNT(*) as cnt, AVG(percentage) as avg_p, MAX(percentage) as best_p FROM quiz_results WHERE user_id = ?", (user_id,))
    q_row = cursor.fetchone()
    quiz_count = q_row["cnt"] if q_row else 0
    avg_score = round(q_row["avg_p"], 1) if q_row and q_row["avg_p"] is not None else 0.0
    best_score = round(q_row["best_p"], 1) if q_row and q_row["best_p"] is not None else 0.0

    # Lessons count
    cursor.execute("SELECT COUNT(*) as cnt FROM offline_lessons WHERE user_id = ?", (user_id,))
    l_row = cursor.fetchone()
    lesson_count = l_row["cnt"] if l_row else 0

    # Documents count
    cursor.execute("SELECT COUNT(*) as cnt FROM pdf_documents WHERE user_id = ?", (user_id,))
    d_row = cursor.fetchone()
    doc_count = d_row["cnt"] if d_row else 0

    # Study groups count
    cursor.execute("SELECT COUNT(*) as cnt FROM group_members WHERE user_id = ?", (user_id,))
    g_row = cursor.fetchone()
    group_count = g_row["cnt"] if g_row else 0

    # Total chat messages
    cursor.execute("""
        SELECT COUNT(*) as cnt FROM chat_messages m
        JOIN chat_sessions s ON m.session_id = s.id
        WHERE s.user_id = ?
    """, (user_id,))
    m_row = cursor.fetchone()
    msg_count = m_row["cnt"] if m_row else 0

    # Fetch user's registered enrolled subjects
    user = get_user_by_id(user_id)
    enrolled_raw = user.get("target_exams") or "Computer Science, Physics, Mathematics" if user else ""
    enrolled_list = [s.strip() for s in enrolled_raw.split(",") if s.strip()]
    if not enrolled_list:
        enrolled_list = ["Computer Science", "Physics", "Mathematics"]
    enrolled_set = set(enrolled_list)

    # Subject performance from quizzes
    cursor.execute("""
        SELECT subject, COUNT(*) as attempts, AVG(percentage) as avg_p
        FROM quiz_results WHERE user_id = ? GROUP BY subject
    """, (user_id,))
    sub_dict = {sr["subject"]: sr for sr in cursor.fetchall()}

    # Subject performance from offline lessons
    cursor.execute("""
        SELECT subject, COUNT(*) as cnt
        FROM offline_lessons WHERE user_id = ? GROUP BY subject
    """, (user_id,))
    lesson_sub_dict = {lr["subject"]: lr["cnt"] for lr in cursor.fetchall()}
    conn.close()

    # Calculate XP and Level
    total_xp = (quiz_count * 75) + (lesson_count * 40) + (doc_count * 50) + (msg_count * 15) + (group_count * 50)
    level = max(1, (total_xp // 250) + 1)
    current_level_xp = total_xp % 250
    xp_to_next = 250 - current_level_xp
    level_progress_pct = int((current_level_xp / 250.0) * 100)

    # Daily Goal (Target: 4 micro-tasks: AI Chat, Practice Quiz, RAG Note, Offline Lesson)
    daily_completed = (1 if quiz_count > 0 else 0) + (1 if lesson_count > 0 else 0) + (1 if msg_count > 0 else 0) + (1 if doc_count > 0 else 0)
    daily_goal_pct = int((daily_completed / 4.0) * 100)

    # Subject Mastery: prioritized by student's actual enrolled subjects, no fake percentages!
    subject_map = {}
    display_subjects = list(enrolled_list)
    # Also include any other subject where the student has taken a quiz or saved a lesson
    for s in list(sub_dict.keys()) + list(lesson_sub_dict.keys()):
        if s and s not in subject_map and s not in display_subjects:
            display_subjects.append(s)

    for subj in display_subjects:
        sr = sub_dict.get(subj)
        l_cnt = lesson_sub_dict.get(subj, 0)
        attempts = sr["attempts"] if sr else 0
        avg_p = sr["avg_p"] if sr and sr["avg_p"] is not None else 0.0

        if attempts > 0:
            score_val = round(avg_p, 1)
            pct = int(min(100, max(15, score_val)))
            status_label = "Mastered 🏆" if score_val >= 85 else ("Proficient ⚡" if score_val >= 70 else "Practicing 📈")
        elif l_cnt > 0:
            pct = int(min(50, l_cnt * 25))
            status_label = f"{l_cnt} Lesson{'s' if l_cnt > 1 else ''} Read 📖"
        else:
            pct = 0
            status_label = "Not Started Yet 🎯"

        subject_map[subj] = {
            "pct": pct,
            "status": status_label,
            "attempts": attempts,
            "lessons": l_cnt,
            "is_enrolled": subj in enrolled_set
        }

    # Achievements / Milestones unlocked
    badges = [
        {"name": "Early Scholar", "icon": "🌱", "desc": "Enrolled & set up learning profile", "unlocked": True},
        {"name": "AI Dialogue Pioneer", "icon": "💬", "desc": "Started interactive AI Socratic session", "unlocked": msg_count >= 1},
        {"name": "Quiz Challenger", "icon": "🎯", "desc": "Completed assessment quiz", "unlocked": quiz_count >= 1},
        {"name": "High Distinction", "icon": "🌟", "desc": "Scored 90%+ on any quiz", "unlocked": best_score >= 90.0},
        {"name": "Document Archivist", "icon": "📑", "desc": "Uploaded lecture notes to RAG", "unlocked": doc_count >= 1},
        {"name": "Study Circle Peer", "icon": "🤝", "desc": "Joined collaborative study group", "unlocked": group_count >= 1},
        {"name": "Offline Sentinel", "icon": "💾", "desc": "Cached offline lesson in WAL SQLite", "unlocked": lesson_count >= 1}
    ]

    return {
        "total_xp": total_xp,
        "level": level,
        "current_level_xp": current_level_xp,
        "xp_to_next": xp_to_next,
        "level_progress_pct": level_progress_pct,
        "daily_completed": daily_completed,
        "daily_goal_pct": daily_goal_pct,
        "streak_days": max(1, min(14, quiz_count + doc_count + (1 if msg_count > 0 else 0))),
        "quiz_count": quiz_count,
        "avg_score": avg_score,
        "best_score": best_score,
        "lesson_count": lesson_count,
        "doc_count": doc_count,
        "group_count": group_count,
        "msg_count": msg_count,
        "subject_mastery": subject_map,
        "badges": badges
    }


# ----------------------------------------------------------------------
# OFFLINE LESSONS & LOCAL CACHE CRUD
# ----------------------------------------------------------------------

def save_offline_lesson(user_id: int, subject: str, topic: str, language: str,
                        summary: str, full_content_markdown: str, key_takeaways: str) -> int:
    """Saves a structured educational lesson to local offline storage."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO offline_lessons (user_id, subject, topic, language, summary, full_content_markdown, key_takeaways)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (user_id, subject, topic, language, summary, full_content_markdown, key_takeaways))
    conn.commit()
    lesson_id = cursor.lastrowid
    conn.close()
    return lesson_id


def get_offline_lessons(user_id: int) -> List[Dict[str, Any]]:
    """Retrieves all offline cached lessons for a user."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT id, subject, topic, language, summary, key_takeaways, is_cached, created_at
        FROM offline_lessons WHERE user_id = ? ORDER BY created_at DESC
    """, (user_id,))
    rows = cursor.fetchall()
    conn.close()
    return [dict(row) for row in rows]


def get_offline_lesson_by_id(lesson_id: int) -> Optional[Dict[str, Any]]:
    """Retrieves complete offline lesson content by lesson ID."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM offline_lessons WHERE id = ?", (lesson_id,))
    row = cursor.fetchone()
    conn.close()
    return dict(row) if row else None


def delete_offline_lesson(lesson_id: int) -> bool:
    """Deletes an offline lesson from cache."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM offline_lessons WHERE id = ?", (lesson_id,))
    conn.commit()
    deleted = cursor.rowcount > 0
    conn.close()
    return deleted


# ----------------------------------------------------------------------
# COLLABORATIVE STUDY GROUPS CRUD
# ----------------------------------------------------------------------

def generate_group_code() -> str:
    """Generates a random, distinct 6-character alphanumeric join code."""
    import random
    import string
    chars = string.ascii_uppercase + string.digits
    chars = chars.replace('O', '').replace('0', '').replace('I', '').replace('1', '')
    return ''.join(random.choices(chars, k=6))


def create_study_group(name: str, description: str, subject: str, creator_id: int) -> Optional[Dict[str, Any]]:
    """Creates a new study group, assigns a unique join code, and enrolls the creator."""
    conn = get_db_connection()
    cursor = conn.cursor()

    join_code = generate_group_code()
    for _ in range(10):
        cursor.execute("SELECT id FROM study_groups WHERE join_code = ?", (join_code,))
        if not cursor.fetchone():
            break
        join_code = generate_group_code()

    try:
        cursor.execute("""
            INSERT INTO study_groups (name, description, subject, join_code, creator_id)
            VALUES (?, ?, ?, ?, ?)
        """, (name.strip(), description.strip(), subject.strip(), join_code, creator_id))
        group_id = cursor.lastrowid

        # Automatically enroll creator as 'admin'
        cursor.execute("""
            INSERT INTO group_members (group_id, user_id, role)
            VALUES (?, ?, 'admin')
        """, (group_id, creator_id))

        # Add welcoming initial message
        cursor.execute("""
            INSERT INTO group_messages (group_id, user_id, message)
            VALUES (?, ?, ?)
        """, (group_id, creator_id, f"Welcome to {name}! Feel free to discuss lecture notes, share PDFs, and challenge each other on quizzes."))

        conn.commit()
        return get_study_group_by_id(group_id)
    except Exception:
        return None
    finally:
        conn.close()


def join_study_group_by_code(user_id: int, join_code: str) -> Tuple[bool, str, Optional[Dict[str, Any]]]:
    """Joins an existing study group using its 6-character join code."""
    conn = get_db_connection()
    cursor = conn.cursor()
    clean_code = join_code.strip().upper()

    cursor.execute("SELECT * FROM study_groups WHERE join_code = ?", (clean_code,))
    group = cursor.fetchone()
    if not group:
        conn.close()
        return False, "Invalid join code. Group not found.", None

    group_id = group["id"]
    cursor.execute("SELECT * FROM group_members WHERE group_id = ? AND user_id = ?", (group_id, user_id))
    existing = cursor.fetchone()
    if existing:
        conn.close()
        return True, "You are already a member of this study group.", dict(group)

    try:
        cursor.execute("""
            INSERT INTO group_members (group_id, user_id, role)
            VALUES (?, ?, 'member')
        """, (group_id, user_id))

        cursor.execute("SELECT full_name FROM users WHERE id = ?", (user_id,))
        user_row = cursor.fetchone()
        uname = user_row["full_name"] if user_row else "A new student"
        cursor.execute("""
            INSERT INTO group_messages (group_id, user_id, message)
            VALUES (?, ?, ?)
        """, (group_id, user_id, f"👋 {uname} joined the study group!"))

        conn.commit()
        return True, f"Successfully joined '{group['name']}'!", dict(group)
    except Exception as e:
        return False, f"Failed to join group: {str(e)}", None
    finally:
        conn.close()


def get_study_group_by_id(group_id: int) -> Optional[Dict[str, Any]]:
    """Retrieves full metadata for a study group."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT g.*, u.full_name as creator_name,
               (SELECT COUNT(*) FROM group_members WHERE group_id = g.id) as member_count,
               (SELECT COUNT(*) FROM group_shared_documents WHERE group_id = g.id) as shared_docs_count,
               (SELECT COUNT(*) FROM group_shared_quizzes WHERE group_id = g.id) as shared_quizzes_count
        FROM study_groups g
        JOIN users u ON g.creator_id = u.id
        WHERE g.id = ?
    """, (group_id,))
    row = cursor.fetchone()
    conn.close()
    return dict(row) if row else None


def get_user_study_groups(user_id: int) -> List[Dict[str, Any]]:
    """Returns all study groups the user belongs to."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT g.*, m.role, m.joined_at, u.full_name as creator_name,
               (SELECT COUNT(*) FROM group_members WHERE group_id = g.id) as member_count,
               (SELECT COUNT(*) FROM group_shared_documents WHERE group_id = g.id) as shared_docs_count,
               (SELECT COUNT(*) FROM group_shared_quizzes WHERE group_id = g.id) as shared_quizzes_count
        FROM study_groups g
        JOIN group_members m ON g.id = m.group_id
        JOIN users u ON g.creator_id = u.id
        WHERE m.user_id = ?
        ORDER BY m.joined_at DESC
    """, (user_id,))
    rows = cursor.fetchall()
    conn.close()
    return [dict(row) for row in rows]


def get_group_members(group_id: int) -> List[Dict[str, Any]]:
    """Returns list of students in a study group."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT u.id, u.username, u.full_name, u.academic_level, u.college_name, m.role, m.joined_at
        FROM group_members m
        JOIN users u ON m.user_id = u.id
        WHERE m.group_id = ?
        ORDER BY m.role DESC, m.joined_at ASC
    """, (group_id,))
    rows = cursor.fetchall()
    conn.close()
    return [dict(row) for row in rows]


def send_group_message(group_id: int, user_id: int, message: str) -> int:
    """Inserts a new chat message into a study group."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO group_messages (group_id, user_id, message)
        VALUES (?, ?, ?)
    """, (group_id, user_id, message.strip()))
    conn.commit()
    msg_id = cursor.lastrowid
    conn.close()
    return msg_id


# Alias for backward compatibility
add_group_message = send_group_message


def get_group_messages(group_id: int, limit: int = 50) -> List[Dict[str, Any]]:
    """Retrieves recent chat messages for a study group."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT msg.id, msg.message, msg.created_at, msg.user_id,
               u.full_name as author_name, u.username as author_username
        FROM group_messages msg
        JOIN users u ON msg.user_id = u.id
        WHERE msg.group_id = ?
        ORDER BY msg.id ASC
        LIMIT ?
    """, (group_id, limit))
    rows = cursor.fetchall()
    conn.close()
    return [dict(row) for row in rows]


def share_document_to_group(group_id: int, doc_id: int, shared_by: int, notes: str = "") -> int:
    """Shares an uploaded PDF note with all members of a study group."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO group_shared_documents (group_id, doc_id, shared_by, notes)
        VALUES (?, ?, ?, ?)
    """, (group_id, doc_id, shared_by, notes.strip()))
    conn.commit()
    share_id = cursor.lastrowid

    cursor.execute("SELECT filename FROM pdf_documents WHERE id = ?", (doc_id,))
    doc_row = cursor.fetchone()
    fname = doc_row["filename"] if doc_row else "a PDF document"
    cursor.execute("""
        INSERT INTO group_messages (group_id, user_id, message)
        VALUES (?, ?, ?)
    """, (group_id, shared_by, f"📎 Shared new lecture note with group: **{fname}**\n\n_{notes}_"))
    conn.commit()

    conn.close()
    return share_id


def get_group_shared_documents(group_id: int) -> List[Dict[str, Any]]:
    """Lists all PDF documents shared with a study group."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT sd.id as share_id, sd.notes as share_notes, sd.shared_at,
               d.id as doc_id, d.filename, d.total_pages, d.total_chunks, d.summary,
               u.full_name as shared_by_name, u.username as shared_by_username
        FROM group_shared_documents sd
        JOIN pdf_documents d ON sd.doc_id = d.id
        JOIN users u ON sd.shared_by = u.id
        WHERE sd.group_id = ?
        ORDER BY sd.shared_at DESC
    """, (group_id,))
    rows = cursor.fetchall()
    conn.close()
    return [dict(row) for row in rows]


def share_quiz_to_group(group_id: int, quiz_result_id: int, shared_by: int,
                        topic: str, score_summary: str, quiz_json: str) -> int:
    """Shares a quiz assessment & peer challenge to a study group."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO group_shared_quizzes (group_id, quiz_result_id, shared_by, topic, score_summary, quiz_json)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (group_id, quiz_result_id, shared_by, topic.strip(), score_summary.strip(), quiz_json))
    conn.commit()
    share_id = cursor.lastrowid

    cursor.execute("""
        INSERT INTO group_messages (group_id, user_id, message)
        VALUES (?, ?, ?)
    """, (group_id, shared_by, f"🎯 Shared a Quiz Challenge: **{topic}** (My Score: {score_summary})! Can you beat it?"))
    conn.commit()

    conn.close()
    return share_id


def get_group_shared_quizzes(group_id: int) -> List[Dict[str, Any]]:
    """Lists all shared quiz challenges in a study group."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT sq.*, u.full_name as shared_by_name, u.username as shared_by_username
        FROM group_shared_quizzes sq
        JOIN users u ON sq.shared_by = u.id
        WHERE sq.group_id = ?
        ORDER BY sq.shared_at DESC
    """, (group_id,))
    rows = cursor.fetchall()
    conn.close()
    return [dict(row) for row in rows]


def leave_study_group(group_id: int, user_id: int) -> bool:
    """Removes a user from a study group."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM group_members WHERE group_id = ? AND user_id = ?", (group_id, user_id))
    conn.commit()
    success = cursor.rowcount > 0
    conn.close()
    return success


# ======================================================================
# EXAM PREPARATION CENTER CRUD HELPERS
# ======================================================================

def add_or_update_exam_subject(user_id: int, subject_name: str, target_date: str = "",
                               readiness_percentage: int = 50, target_score: str = "A* (90%+)",
                               notes: str = "") -> int:
    """Adds a new subject or updates readiness in the student's exam preparation tracker."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT id FROM exam_subjects WHERE user_id = ? AND LOWER(subject_name) = LOWER(?)
    """, (user_id, subject_name.strip()))
    existing = cursor.fetchone()

    if existing:
        cursor.execute("""
            UPDATE exam_subjects
            SET target_date = ?, readiness_percentage = ?, target_score = ?, notes = ?, updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        """, (target_date, readiness_percentage, target_score, notes, existing["id"]))
        subject_id = existing["id"]
    else:
        cursor.execute("""
            INSERT INTO exam_subjects (user_id, subject_name, target_date, readiness_percentage, target_score, notes)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (user_id, subject_name.strip(), target_date, readiness_percentage, target_score, notes))
        subject_id = cursor.lastrowid

    conn.commit()
    conn.close()
    return subject_id


def get_user_exam_subjects(user_id: int) -> List[Dict[str, Any]]:
    """Retrieves all tracked exam subjects for a user ordered by target readiness."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT * FROM exam_subjects WHERE user_id = ? ORDER BY readiness_percentage ASC, id DESC
    """, (user_id,))
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]


def delete_exam_subject(subject_id: int, user_id: int) -> bool:
    """Deletes an exam subject from tracking."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM exam_subjects WHERE id = ? AND user_id = ?", (subject_id, user_id))
    conn.commit()
    ok = cursor.rowcount > 0
    conn.close()
    return ok


def add_flashcard(user_id: int, subject: str, topic: str, front_text: str, back_text: str, category: str = "Concept") -> int:
    """Adds a single flashcard to the user's exam deck."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO exam_flashcards (user_id, subject, topic, front_text, back_text, category, status)
        VALUES (?, ?, ?, ?, ?, ?, 'new')
    """, (user_id, subject, topic, front_text, back_text, category))
    conn.commit()
    cid = cursor.lastrowid
    conn.close()
    return cid


def add_flashcards_bulk(user_id: int, subject: str, topic: str, cards: List[Dict[str, str]]) -> int:
    """Adds multiple flashcards in a batch."""
    conn = get_db_connection()
    cursor = conn.cursor()
    count = 0
    for card in cards:
        f = card.get("front") or card.get("front_text") or card.get("question") or ""
        b = card.get("back") or card.get("back_text") or card.get("answer") or ""
        cat = card.get("category", "High-Yield Concept")
        if f and b:
            cursor.execute("""
                INSERT INTO exam_flashcards (user_id, subject, topic, front_text, back_text, category, status)
                VALUES (?, ?, ?, ?, ?, ?, 'new')
            """, (user_id, subject, topic, f, b, cat))
            count += 1
    conn.commit()
    conn.close()
    return count


def get_user_flashcards(user_id: int, subject: Optional[str] = None, status: Optional[str] = None) -> List[Dict[str, Any]]:
    """Fetches user flashcards filtered optionally by subject and mastery status."""
    conn = get_db_connection()
    cursor = conn.cursor()
    query = "SELECT * FROM exam_flashcards WHERE user_id = ?"
    params = [user_id]
    if subject and subject != "All Subjects":
        query += " AND subject = ?"
        params.append(subject)
    if status and status != "All":
        query += " AND status = ?"
        params.append(status)
    query += " ORDER BY id DESC"
    cursor.execute(query, tuple(params))
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]


def update_flashcard_status(card_id: int, user_id: int, status: str) -> bool:
    """Updates confidence / mastery status of a flashcard ('mastered', 'review', 'new')."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE exam_flashcards SET status = ? WHERE id = ? AND user_id = ?", (status, card_id, user_id))
    conn.commit()
    ok = cursor.rowcount > 0
    conn.close()
    return ok


def delete_flashcard(card_id: int, user_id: int) -> bool:
    """Deletes a flashcard."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM exam_flashcards WHERE id = ? AND user_id = ?", (card_id, user_id))
    conn.commit()
    ok = cursor.rowcount > 0
    conn.close()
    return ok


def save_mindmap(user_id: int, subject: str, topic: str, mermaid_code: str, summary: str = "") -> int:
    """Saves a generated interactive mind map for quick visual review."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO exam_mindmaps (user_id, subject, topic, mermaid_code, summary)
        VALUES (?, ?, ?, ?, ?)
    """, (user_id, subject, topic, mermaid_code, summary))
    conn.commit()
    mid = cursor.lastrowid
    conn.close()
    return mid


def get_user_mindmaps(user_id: int, subject: Optional[str] = None) -> List[Dict[str, Any]]:
    """Retrieves user's saved mind maps."""
    conn = get_db_connection()
    cursor = conn.cursor()
    if subject and subject != "All":
        cursor.execute("SELECT * FROM exam_mindmaps WHERE user_id = ? AND subject = ? ORDER BY id DESC", (user_id, subject))
    else:
        cursor.execute("SELECT * FROM exam_mindmaps WHERE user_id = ? ORDER BY id DESC", (user_id,))
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]


def save_guess_paper(user_id: int, subject: str, exam_board: str, academic_level: str,
                     model_paper_input: str, analysis_json: str, guess_paper_markdown: str) -> int:
    """Saves an AI predicted Guess Paper (Paper Crack analysis)."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO exam_guess_papers (user_id, subject, exam_board, academic_level, model_paper_input, analysis_json, guess_paper_markdown)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (user_id, subject, exam_board, academic_level, model_paper_input, analysis_json, guess_paper_markdown))
    conn.commit()
    gid = cursor.lastrowid
    conn.close()
    return gid


def get_user_guess_papers(user_id: int) -> List[Dict[str, Any]]:
    """Retrieves all generated guess papers for a user."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT * FROM exam_guess_papers WHERE user_id = ? ORDER BY id DESC
    """, (user_id,))
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_guess_paper_by_id(paper_id: int, user_id: int) -> Optional[Dict[str, Any]]:
    """Gets a specific guess paper."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM exam_guess_papers WHERE id = ? AND user_id = ?", (paper_id, user_id))
    row = cursor.fetchone()
    conn.close()
    return dict(row) if row else None


def save_exam_revision_note(user_id: int, subject: str, topic: str, notes_markdown: str) -> int:
    """Saves high-yield revision cheat sheet notes."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO exam_revision_notes (user_id, subject, topic, notes_markdown)
        VALUES (?, ?, ?, ?)
    """, (user_id, subject, topic, notes_markdown))
    conn.commit()
    nid = cursor.lastrowid
    conn.close()
    return nid


def get_user_exam_revision_notes(user_id: int, subject: Optional[str] = None) -> List[Dict[str, Any]]:
    """Gets saved revision cheat sheets."""
    conn = get_db_connection()
    cursor = conn.cursor()
    if subject and subject != "All":
        cursor.execute("SELECT * FROM exam_revision_notes WHERE user_id = ? AND subject = ? ORDER BY id DESC", (user_id, subject))
    else:
        cursor.execute("SELECT * FROM exam_revision_notes WHERE user_id = ? ORDER BY id DESC", (user_id,))
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]


# Run initialization on import to ensure all tables and migrations exist
init_db()
