package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme {
        Scaffold(
          modifier = Modifier.fillMaxSize(),
          topBar = {
            @OptIn(ExperimentalMaterial3Api::class)
            TopAppBar(
              title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(32.dp)
                  ) {
                    Box(contentAlignment = Alignment.Center) {
                      Icon(Icons.Default.School, contentDescription = "Logo", tint = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(18.dp))
                    }
                  }
                  Spacer(modifier = Modifier.width(10.dp))
                  Column {
                    Text(
                      "EduGlobal AI",
                      style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                      "Gemini 3.8 Live & Offline WAL",
                      style = MaterialTheme.typography.labelSmall,
                      color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                  }
                }
              },
              colors = TopAppBarDefaults.topAppBarColors(
                containerColor = MaterialTheme.colorScheme.surface,
                titleContentColor = MaterialTheme.colorScheme.onSurface
              )
            )
          }
        ) { innerPadding ->
          EduGlobalDashboard(modifier = Modifier.padding(innerPadding))
        }
      }
    }
  }
}

@Composable
fun EduGlobalDashboard(modifier: Modifier = Modifier) {
  var selectedTab by remember { mutableStateOf(0) }
  val tabs = listOf("Overview", "Progress", "Gemini Chat", "Live Voice", "Groups", "MCQ Quiz", "Lessons")

  Column(modifier = modifier.fillMaxSize()) {
    ScrollableTabRow(
      selectedTabIndex = selectedTab,
      edgePadding = 12.dp,
      containerColor = MaterialTheme.colorScheme.surface
    ) {
      tabs.forEachIndexed { index, title ->
        Tab(
          selected = selectedTab == index,
          onClick = { selectedTab = index },
          text = { 
            Text(
              title,
              fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal
            ) 
          }
        )
      }
    }

    when (selectedTab) {
      0 -> OverviewScreen(onNavigateToProgress = { selectedTab = 1 })
      1 -> ProgressPanelScreen()
      2 -> AITutorScreen()
      3 -> LiveVoiceScreen()
      4 -> StudyGroupsScreen()
      5 -> MCQQuizScreen()
      6 -> OfflineLessonsScreen()
    }
  }
}

@Composable
fun OverviewScreen(onNavigateToProgress: () -> Unit = {}) {
  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    item {
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .clickable { onNavigateToProgress() }
          .testTag("progress_preview_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Text(
                "🏆 Level 3 Scholar",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onPrimaryContainer
              )
              Spacer(modifier = Modifier.width(8.dp))
              Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
              ) {
                Text(
                  "🔥 5d Streak",
                  style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                  color = MaterialTheme.colorScheme.primary,
                  modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
              }
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              "Daily Target: 3/4 tasks (75%) • 420 Knowledge XP",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
            )
          }
          FilledTonalButton(
            onClick = onNavigateToProgress,
            modifier = Modifier.testTag("view_progress_button")
          ) {
            Text("View Progress")
          }
        }
      }
    }

    item {
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .testTag("hub_status_card"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.School, contentDescription = "Education Icon", tint = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              "System Architecture & Deliverables",
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold)
            )
          }
          Spacer(modifier = Modifier.height(12.dp))
          StatusRow("Frontend UI", "Streamlit Multi-Tab Web App (app.py)", Icons.Default.Web)
          StatusRow("Backend Engine", "FastAPI + Uvicorn (main.py)", Icons.Default.Dns)
          StatusRow("Database", "eduglobal_offline.db (SQLite WAL)", Icons.Default.Storage)
          StatusRow("LLM Engine", "gemini-3.6-flash (Google GenAI)", Icons.Default.Psychology)
          StatusRow("Document Engine", "PyPDF / pdfplumber RAG Extractor", Icons.Default.Description)
          StatusRow("Security", "SHA-256 Hashing with dynamic salt", Icons.Default.Security)
        }
      }
    }

    item {
      Text(
        "Key App Modules",
        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
        color = MaterialTheme.colorScheme.primary
      )
    }

    item {
      ModuleCard(
        title = "1. Authentication & Profile",
        description = "SHA-256 hashed credentials, persistent SQLite session state, academic level and language preference tracking.",
        icon = Icons.Default.AccountCircle
      )
    }

    item {
      ModuleCard(
        title = "2. Interactive AI Tutor",
        description = "Context-aware conversational tutor supporting Urdu, English, Roman Urdu, and bilingual answers with LaTeX equations and diagrams.",
        icon = Icons.Default.Forum
      )
    }

    item {
      ModuleCard(
        title = "3. PDF & RAG Notes Reader",
        description = "Automatic text extraction, semantic chunking, and injection of lecture notes context into the AI Tutor pipeline.",
        icon = Icons.Default.PictureAsPdf
      )
    }

    item {
      ModuleCard(
        title = "4. Smart MCQ Quiz Generator",
        description = "Curriculum-aligned question generation, interactive radio button testing, real-time scoring, and database logging.",
        icon = Icons.Default.Quiz
      )
    }

    item {
      ModuleCard(
        title = "5. Offline Lesson Downloader",
        description = "Permanent local SQLite storage for generated curriculum chapters enabling zero-internet study.",
        icon = Icons.Default.DownloadForOffline
      )
    }

    item {
      ModuleCard(
        title = "6. Analytics & Progress Tracker",
        description = "Visual score progress, quiz history, and completed lessons tracker for logged-in students.",
        icon = Icons.Default.Analytics
      )
    }
  }
}

@Composable
fun StatusRow(label: String, value: String, icon: ImageVector) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 4.dp),
    verticalAlignment = Alignment.CenterVertically
  ) {
    Icon(icon, contentDescription = label, modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.primary)
    Spacer(modifier = Modifier.width(8.dp))
    Text(
      text = "$label: ",
      style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold)
    )
    Text(
      text = value,
      style = MaterialTheme.typography.bodySmall,
      color = MaterialTheme.colorScheme.onSurfaceVariant
    )
  }
}

@Composable
fun ModuleCard(title: String, description: String, icon: ImageVector) {
  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(8.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
  ) {
    Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.Top) {
      Icon(icon, contentDescription = title, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(24.dp))
      Spacer(modifier = Modifier.width(12.dp))
      Column {
        Text(title, style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold))
        Spacer(modifier = Modifier.height(4.dp))
        Text(description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
      }
    }
  }
}

@Composable
fun AITutorScreen() {
  var prompt by remember { mutableStateOf("") }
  var selectedModelIndex by remember { mutableStateOf(0) }
  val models = listOf("gemini-3.5-flash", "gemini-3.1-pro-preview", "gemini-3.1-flash-lite")
  
  var selectedRoleIndex by remember { mutableStateOf(0) }
  val roles = listOf("🎓 Socratic Tutor", "⚡ Rapid Solver", "🔬 STEM Researcher")

  var messages by remember {
    mutableStateOf(
      listOf(
        Pair("user", "Explain Newton's Second Law in Roman Urdu with LaTeX formula."),
        Pair("assistant", "Newton ka doosra qanoon (Second Law of Motion) yeh bayan karta hai ke kisi jism par lagne wali force uske mass aur acceleration ke product ke barabar hoti hai:\n\n\$\$F = m \\cdot a\$\$\n\nYahan:\n• \$F\$ = Net Force (Newtons mein)\n• \$m\$ = Mass (kg mein)\n• \$a\$ = Acceleration (m/s² mein)\n\nKya aap chahte hain ke hum is par ek numerical problem solve karein?"),
        Pair("user", "Yes, if mass is 5kg and acceleration is 3m/s^2, what is force?"),
        Pair("assistant", "Shabash! Formula lagatay hain:\n\n\$\$F = m \\cdot a\$\$\n\$\$F = 5\\text{ kg} \\times 3\\text{ m/s}^2 = 15\\text{ N}\$\$\n\nTotal Force 15 Newtons hogi! 🎯")
      )
    )
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp)
  ) {
    Text(
      "Gemini Academic Chatbot",
      style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
    )

    // Model Selector Chips
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
      models.forEachIndexed { idx, mod ->
        FilterChip(
          selected = selectedModelIndex == idx,
          onClick = { selectedModelIndex = idx },
          label = { Text(mod.replace("gemini-", ""), fontSize = 11.sp) },
          colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer
          )
        )
      }
    }

    // Role Persona Chips
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
      roles.forEachIndexed { idx, role ->
        FilterChip(
          selected = selectedRoleIndex == idx,
          onClick = { selectedRoleIndex = idx },
          label = { Text(role, fontSize = 11.sp) }
        )
      }
    }

    // Scrollable Conversation History
    LazyColumn(
      modifier = Modifier
        .weight(1f)
        .fillMaxWidth(),
      verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      items(messages) { (role, content) ->
        val isUser = role == "user"
        Column(
          modifier = Modifier.fillMaxWidth(),
          horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
        ) {
          Surface(
            shape = RoundedCornerShape(
              topStart = 14.dp,
              topEnd = 14.dp,
              bottomStart = if (isUser) 14.dp else 2.dp,
              bottomEnd = if (isUser) 2.dp else 14.dp
            ),
            color = if (isUser) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
            tonalElevation = 2.dp,
            modifier = Modifier.widthIn(max = 310.dp)
          ) {
            Column(modifier = Modifier.padding(12.dp)) {
              if (!isUser) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(Icons.Default.AutoAwesome, contentDescription = "AI", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(14.dp))
                  Spacer(modifier = Modifier.width(4.dp))
                  Text(
                    "Gemini (${models[selectedModelIndex]})",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.primary
                  )
                }
                Spacer(modifier = Modifier.height(4.dp))
              }
              Text(
                content,
                style = MaterialTheme.typography.bodyMedium,
                color = if (isUser) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }
        }
      }
    }

    // Input Bar
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically
    ) {
      OutlinedTextField(
        value = prompt,
        onValueChange = { prompt = it },
        placeholder = { Text("Ask anything across STEM...") },
        modifier = Modifier.weight(1f),
        singleLine = true
      )
      Spacer(modifier = Modifier.width(8.dp))
      IconButton(
        onClick = {
          if (prompt.isNotBlank()) {
            val userText = prompt
            messages = messages + Pair("user", userText)
            prompt = ""
            // Add automated intelligent reply
            messages = messages + Pair(
              "assistant",
              "Reasoning as ${roles[selectedRoleIndex]} with ${models[selectedModelIndex]}:\n\nRegarding '$userText', let's break down the underlying mathematical and physical principles step-by-step."
            )
          }
        },
        modifier = Modifier
          .background(MaterialTheme.colorScheme.primary, shape = CircleShape)
          .testTag("tutor_ask_button")
      ) {
        Icon(Icons.Default.Send, contentDescription = "Send", tint = MaterialTheme.colorScheme.onPrimary)
      }
    }
  }
}

@Composable
fun LiveVoiceScreen() {
  var isRecording by remember { mutableStateOf(false) }
  val infiniteTransition = rememberInfiniteTransition(label = "wave_anim")
  val wavePhase by infiniteTransition.animateFloat(
    initialValue = 0f,
    targetValue = 6.28f,
    animationSpec = infiniteRepeatable(
      animation = tween(1200, easing = LinearEasing),
      repeatMode = RepeatMode.Restart
    ),
    label = "wave_phase"
  )

  var voiceLog by remember {
    mutableStateOf(
      listOf(
        Pair("Student", "Explain quantum tunneling in simple conversational terms."),
        Pair("Gemini 3.8 Live", "Imagine you are throwing a tennis ball against a brick wall. In classical physics, it always bounces back. But in quantum physics, because the electron behaves like a wave of probabilities, there is a small chance its wave leaks right through the wall! That's how modern flash memory works.")
      )
    )
  }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp),
    horizontalAlignment = Alignment.CenterHorizontally
  ) {
    item {
      Text(
        "🎙️ Gemini 3.8 Live Voice Studio",
        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
      )
      Text(
        "Low-latency voice conversations powered by Live API.",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )
    }

    // Audio Waveform Canvas
    item {
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .height(110.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A))
      ) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
          Canvas(modifier = Modifier.fillMaxSize().padding(16.dp)) {
            val numBars = 18
            val barWidth = size.width / (numBars * 2f)
            val centerY = size.height / 2f
            for (i in 0 until numBars) {
              val x = i * (barWidth * 2) + barWidth / 2
              val heightFactor = if (isRecording) {
                0.3f + 0.7f * kotlin.math.abs(kotlin.math.sin(wavePhase + i * 0.4f)).toFloat()
              } else {
                0.15f + 0.35f * kotlin.math.abs(kotlin.math.sin(wavePhase * 0.5f + i * 0.2f)).toFloat()
              }
              val barHeight = size.height * heightFactor
              drawRoundRect(
                brush = Brush.verticalGradient(
                  colors = listOf(Color(0xFF06B6D4), Color(0xFF6366F1))
                ),
                topLeft = Offset(x, centerY - barHeight / 2),
                size = Size(barWidth, barHeight),
                cornerRadius = CornerRadius(4f, 4f)
              )
            }
          }
        }
      }
    }

    item {
      Surface(
        shape = RoundedCornerShape(20.dp),
        color = if (isRecording) Color(0xFFEF4444).copy(alpha = 0.15f) else Color(0xFF06B6D4).copy(alpha = 0.15f)
      ) {
        Text(
          text = if (isRecording) "🔴 LIVE LISTENING (Gemini 3.8 Live Active)..." else "🟢 TAP MICROPHONE TO SPEAK",
          style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
          color = if (isRecording) Color(0xFFEF4444) else Color(0xFF06B6D4),
          modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
        )
      }
    }

    // Big Glowing Microphone Button
    item {
      Box(
        modifier = Modifier
          .size(80.dp)
          .clip(CircleShape)
          .background(
            if (isRecording) Brush.linearGradient(listOf(Color(0xFFEF4444), Color(0xFFF43F5E)))
            else Brush.linearGradient(listOf(Color(0xFF06B6D4), Color(0xFF6366F1)))
          )
          .clickable {
            isRecording = !isRecording
            if (!isRecording) {
              voiceLog = voiceLog + Pair("Student", "Can you explain Bernoulli's principle?")
              voiceLog = voiceLog + Pair("Gemini 3.8 Live", "Sure! When a fluid moves faster, its internal pressure drops. That pressure difference creates lift on airplane wings!")
            }
          },
        contentAlignment = Alignment.Center
      ) {
        Icon(
          if (isRecording) Icons.Default.Mic else Icons.Default.MicNone,
          contentDescription = "Microphone",
          tint = Color.White,
          modifier = Modifier.size(36.dp)
        )
      }
    }

    item {
      Text(
        "Live Audio Dialogue Stream",
        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
        modifier = Modifier.fillMaxWidth()
      )
    }

    items(voiceLog.size) { idx ->
      val (speaker, text) = voiceLog[idx]
      val isGemini = speaker.contains("Gemini")
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
          containerColor = if (isGemini) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
          else MaterialTheme.colorScheme.surface
        )
      ) {
        Column(modifier = Modifier.padding(12.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              if (isGemini) Icons.Default.AutoAwesome else Icons.Default.Person,
              contentDescription = speaker,
              modifier = Modifier.size(16.dp),
              tint = if (isGemini) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              speaker,
              style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
              color = if (isGemini) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
            )
          }
          Spacer(modifier = Modifier.height(4.dp))
          Text(text, style = MaterialTheme.typography.bodySmall)
        }
      }
    }
  }
}

@Composable
fun StudyGroupsScreen() {
  var chatInput by remember { mutableStateOf("") }
  var messages by remember {
    mutableStateOf(
      listOf(
        Triple("Alice Scholar", "Welcome to the Quantum Mechanics circle! Feel free to share your notes.", "10:15 AM"),
        Triple("Bob Learner", "Thanks Alice! Has anyone solved the 1D infinite well boundary condition problem?", "10:18 AM"),
        Triple("Zainab Ahmed", "Yes! Just shared my lecture PDF notes in the group notes library.", "10:22 AM")
      )
    )
  }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    item {
      Text(
        "👥 Collaborative Study Groups",
        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
      )
      Text(
        "Peer learning circles with shared lecture notes, quiz challenges, and live chat.",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )
    }

    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              "Quantum Mechanics & Calculus Circle",
              style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
            )
            Surface(
              shape = RoundedCornerShape(4.dp),
              color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
            ) {
              Text(
                " CODE: SJYDZV ",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
              )
            }
          }
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            "Subject: Physics • 3 Members • 2 Shared Notes • 1 Quiz Challenge",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }
    }

    item {
      Text(
        "💬 Live Study Discussion",
        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
      )
    }

    items(messages.size) { idx ->
      val (author, msg, time) = messages[idx]
      Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
      ) {
        Column(modifier = Modifier.padding(10.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(author, style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold), color = MaterialTheme.colorScheme.primary)
            Text(time, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
          }
          Spacer(modifier = Modifier.height(3.dp))
          Text(msg, style = MaterialTheme.typography.bodySmall)
        }
      }
    }

    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
      ) {
        OutlinedTextField(
          value = chatInput,
          onValueChange = { chatInput = it },
          placeholder = { Text("Type discussion message...") },
          modifier = Modifier.weight(1f),
          singleLine = true
        )
        Spacer(modifier = Modifier.width(8.dp))
        Button(
          onClick = {
            if (chatInput.isNotBlank()) {
              messages = messages + Triple("You (Student)", chatInput, "Just now")
              chatInput = ""
            }
          },
          modifier = Modifier.testTag("send_group_chat_button")
        ) {
          Text("Send")
        }
      }
    }

    item {
      Text(
        "📑 Group Shared Notes & Peer Challenges",
        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
      )
    }

    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f))
      ) {
        Column(modifier = Modifier.padding(12.dp)) {
          Text("📄 Lecture_4_Schrodinger_Derivation.pdf", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold))
          Text("Shared by Zainab Ahmed • 12 Pages • 10 Chunks indexed for RAG", style = MaterialTheme.typography.bodySmall)
          Spacer(modifier = Modifier.height(4.dp))
          Text("🎯 Challenge: Quantum Basics Quiz (Top Score: 100%)", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold), color = MaterialTheme.colorScheme.primary)
        }
      }
    }
  }
}

@Composable
fun MCQQuizScreen() {
  var selectedOption by remember { mutableStateOf(0) }
  var isSubmitted by remember { mutableStateOf(false) }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    Text("Smart MCQ Assessment Demo", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
    Card(modifier = Modifier.fillMaxWidth()) {
      Column(modifier = Modifier.padding(16.dp)) {
        Text(
          "Q1. In thermodynamics, which fundamental law states that the entropy of an isolated system always increases?",
          style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.SemiBold)
        )
        Spacer(modifier = Modifier.height(8.dp))
        val options = listOf(
          "Zeroth Law of Thermodynamics",
          "First Law of Thermodynamics",
          "Second Law of Thermodynamics (Entropy Law)",
          "Third Law of Thermodynamics"
        )
        options.forEachIndexed { index, opt ->
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
          ) {
            RadioButton(
              selected = selectedOption == index,
              onClick = { if (!isSubmitted) selectedOption = index }
            )
            Text(opt, style = MaterialTheme.typography.bodyMedium)
          }
        }

        Spacer(modifier = Modifier.height(12.dp))
        Button(
          onClick = { isSubmitted = true },
          modifier = Modifier.fillMaxWidth().testTag("submit_quiz_button"),
          enabled = !isSubmitted
        ) {
          Text(if (isSubmitted) "Scored: 100% (Logged to quiz_results)" else "Submit Answer")
        }

        if (isSubmitted) {
          Spacer(modifier = Modifier.height(8.dp))
          Text(
            "✅ Correct! The Second Law states \$\$\\Delta S \\ge 0\$\$, meaning total entropy never decreases in an isolated system.",
            color = MaterialTheme.colorScheme.primary,
            style = MaterialTheme.typography.bodySmall
          )
        }
      }
    }
  }
}

@Composable
fun OfflineLessonsScreen() {
  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    Text("Offline Lesson Downloader & Local Cache", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
    Text(
      "Lessons stored in SQLite 'offline_lessons' table. Accessible without internet connectivity.",
      style = MaterialTheme.typography.bodySmall,
      color = MaterialTheme.colorScheme.onSurfaceVariant
    )

    Card(modifier = Modifier.fillMaxWidth()) {
      Column(modifier = Modifier.padding(14.dp)) {
        Text("📖 Quantum Harmonic Oscillator", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
        Text("Physics • Undergraduate Level • Cached in SQLite", style = MaterialTheme.typography.bodySmall)
        Spacer(modifier = Modifier.height(8.dp))
        Text(
          "The Hamiltonian for a one-dimensional quantum harmonic oscillator is:\n\n\$\\$\\hat{H} = \\frac{\\hat{p}^2}{2m} + \\frac{1}{2}m\\omega^2\\hat{x}^2\$\$\n\nEnergy eigenvalues: \$\$E_n = \\hbar\\omega\\left(n + \\frac{1}{2}\\right)\$\$, where n = 0, 1, 2, ...",
          style = MaterialTheme.typography.bodySmall
        )
      }
    }
  }
}

@Composable
fun ProgressPanelScreen() {
  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp)
      .testTag("progress_panel_screen"),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    item {
      Column {
        Text(
          "Student Progress & Mastery Panel",
          style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.onSurface
        )
        Text(
          "Real-time scholar XP progression, daily targets, subject mastery trajectory, and unlocked milestones.",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }
    }

    // Top Metric Tiles (2x2 Grid)
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        Card(
          modifier = Modifier.weight(1f).testTag("metric_card_tier"),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
          Column(
            modifier = Modifier.padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Text("Lvl 3", style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold), color = MaterialTheme.colorScheme.primary)
            Text("SCHOLAR TIER", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold), color = MaterialTheme.colorScheme.outline)
          }
        }
        Card(
          modifier = Modifier.weight(1f).testTag("metric_card_xp"),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
          Column(
            modifier = Modifier.padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Text("420", style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold), color = MaterialTheme.colorScheme.tertiary)
            Text("KNOWLEDGE XP", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold), color = MaterialTheme.colorScheme.outline)
          }
        }
      }
    }

    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        Card(
          modifier = Modifier.weight(1f).testTag("metric_card_streak"),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
          Column(
            modifier = Modifier.padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Text("🔥 5 Days", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold), color = MaterialTheme.colorScheme.error)
            Text("STUDY STREAK", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold), color = MaterialTheme.colorScheme.outline)
          }
        }
        Card(
          modifier = Modifier.weight(1f).testTag("metric_card_score"),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
          Column(
            modifier = Modifier.padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Text("86.5%", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold), color = MaterialTheme.colorScheme.secondary)
            Text("AVG QUIZ SCORE", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold), color = MaterialTheme.colorScheme.outline)
          }
        }
      }
    }

    // Scholar Level Progression Card
    item {
      Card(
        modifier = Modifier.fillMaxWidth().testTag("level_progression_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text("Level 3 Scholar", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
            Text("170 / 250 XP", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold), color = MaterialTheme.colorScheme.primary)
          }
          Spacer(modifier = Modifier.height(8.dp))
          LinearProgressIndicator(
            progress = { 170f / 250f },
            modifier = Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(5.dp)),
            color = MaterialTheme.colorScheme.primary,
            trackColor = MaterialTheme.colorScheme.surface
          )
          Spacer(modifier = Modifier.height(6.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text("Current: Lvl 3", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
            Text("80 XP needed for Level 4", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
          }
        }
      }
    }

    // Daily Goals Checklist Card
    item {
      Card(
        modifier = Modifier.fillMaxWidth().testTag("daily_goals_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text("🎯 Daily Micro-Learning Target", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
            Surface(
              shape = RoundedCornerShape(12.dp),
              color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
            ) {
              Text(
                "3/4 (75%)",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
              )
            }
          }
          Spacer(modifier = Modifier.height(10.dp))
          DailyGoalTaskRow("💬 Multi-turn AI Socratic Dialogue", isCompleted = true)
          DailyGoalTaskRow("📝 Complete Adaptive MCQ Quiz", isCompleted = true)
          DailyGoalTaskRow("📑 Upload or Review RAG Lecture Note", isCompleted = true)
          DailyGoalTaskRow("💾 Cache Offline Study Chapter", isCompleted = false)
        }
      }
    }

    // Subject Mastery Trajectory Card
    item {
      Card(
        modifier = Modifier.fillMaxWidth().testTag("subject_mastery_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text("📚 Subject Mastery Trajectory", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
          Spacer(modifier = Modifier.height(12.dp))
          SubjectMasteryItem("Mathematics", 0.85f, "85%", "Mastered 🏆", 8)
          SubjectMasteryItem("Physics", 0.78f, "78%", "Proficient ⚡", 6)
          SubjectMasteryItem("Computer Science", 0.92f, "92%", "Mastered 🏆", 5)
          SubjectMasteryItem("Chemistry", 0.65f, "65%", "Developing 📈", 3)
          SubjectMasteryItem("Biology", 0.58f, "58%", "Developing 📈", 2)
        }
      }
    }

    // Milestones & Badges
    item {
      Card(
        modifier = Modifier.fillMaxWidth().testTag("milestones_badges_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text("🏆 Milestones & Achievement Badges", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
          Spacer(modifier = Modifier.height(12.dp))
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            BadgeChip("🌱", "Early Scholar", isUnlocked = true, modifier = Modifier.weight(1f))
            BadgeChip("💬", "AI Pioneer", isUnlocked = true, modifier = Modifier.weight(1f))
          }
          Spacer(modifier = Modifier.height(8.dp))
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            BadgeChip("🎯", "Quiz Master", isUnlocked = true, modifier = Modifier.weight(1f))
            BadgeChip("🌟", "Distinction", isUnlocked = true, modifier = Modifier.weight(1f))
          }
          Spacer(modifier = Modifier.height(8.dp))
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            BadgeChip("📑", "Archivist", isUnlocked = true, modifier = Modifier.weight(1f))
            BadgeChip("💾", "Offline Pro", isUnlocked = false, modifier = Modifier.weight(1f))
          }
        }
      }
    }

    // Recent Assessment History
    item {
      Card(
        modifier = Modifier.fillMaxWidth().testTag("recent_assessments_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text("📜 Recent Quiz History", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
          Spacer(modifier = Modifier.height(10.dp))
          AssessmentHistoryItem("Thermodynamics & Carnot Cycle", "Physics", "5/5 (100%)", "High School")
          AssessmentHistoryItem("Calculus: Fundamental Theorem", "Mathematics", "4/5 (80%)", "Undergraduate")
          AssessmentHistoryItem("Organic Reaction Mechanisms", "Chemistry", "4/5 (80%)", "High School")
        }
      }
    }
  }
}

@Composable
fun DailyGoalTaskRow(title: String, isCompleted: Boolean) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 4.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Text(title, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface)
    if (isCompleted) {
      Text("✅ Done", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold), color = MaterialTheme.colorScheme.primary)
    } else {
      Text("⏳ Pending", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
    }
  }
}

@Composable
fun SubjectMasteryItem(name: String, progress: Float, pctText: String, status: String, attempts: Int) {
  Column(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(name, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold))
      Text("$pctText • $status", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold), color = MaterialTheme.colorScheme.primary)
    }
    Spacer(modifier = Modifier.height(4.dp))
    LinearProgressIndicator(
      progress = { progress },
      modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
      color = MaterialTheme.colorScheme.primary,
      trackColor = MaterialTheme.colorScheme.surface
    )
    Spacer(modifier = Modifier.height(2.dp))
    Text("$attempts Assessments Attempted", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
  }
}

@Composable
fun BadgeChip(icon: String, name: String, isUnlocked: Boolean, modifier: Modifier = Modifier) {
  Surface(
    modifier = modifier,
    shape = RoundedCornerShape(12.dp),
    color = if (isUnlocked) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surface.copy(alpha = 0.5f),
    tonalElevation = if (isUnlocked) 2.dp else 0.dp
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(icon, style = MaterialTheme.typography.titleMedium)
      Spacer(modifier = Modifier.width(6.dp))
      Column {
        Text(name, style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
        Text(
          if (isUnlocked) "Unlocked" else "In Progress",
          style = MaterialTheme.typography.labelSmall,
          color = if (isUnlocked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
        )
      }
    }
  }
}

@Composable
fun AssessmentHistoryItem(topic: String, subject: String, score: String, level: String) {
  Surface(
    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
    shape = RoundedCornerShape(8.dp),
    color = MaterialTheme.colorScheme.surface
  ) {
    Row(
      modifier = Modifier.padding(10.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Column(modifier = Modifier.weight(1f)) {
        Text(topic, style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold))
        Text("$subject • $level", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
      }
      Surface(
        shape = RoundedCornerShape(6.dp),
        color = MaterialTheme.colorScheme.primaryContainer
      ) {
        Text(
          score,
          style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.onPrimaryContainer,
          modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
      }
    }
  }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
  Text(text = "Hello $name!", modifier = modifier)
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
  MyApplicationTheme { Greeting("Android") }
}

